#!/usr/bin/perl -w
use strict;
use SVG;

exit 1;
